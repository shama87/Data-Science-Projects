input_file <- "Clothing (1).csv"

if (!file.exists(input_file)) {
  input_file <- file.choose()
}

output_folder <- "Clothing_Project_Output"

if (!dir.exists(output_folder)) {
  dir.create(output_folder)
}

clothing <- read.csv(input_file, header = TRUE, sep = ",", stringsAsFactors = FALSE)

names(clothing)[1] <- "Store_ID"

cat("1. DATASET SELECTION AND FEATURE PREPARATION\n")
print(head(clothing))
print(dim(clothing))
print(names(clothing))
str(clothing)
print(summary(clothing))

cat("SELECTED ROWS\n")
print(clothing[5:10, ])

cat("SELECTED COLUMN\n")
print(head(clothing$sales))

cat("SUBSET OF DATA\n")
print(head(subset(clothing, sales >= 5000)))

clothing$Margin_Level <- ifelse(clothing$margin < 38, "Low", ifelse(clothing$margin <= 41, "Medium", "High"))
clothing$Margin_Level <- factor(clothing$Margin_Level, levels = c("Low", "Medium", "High"))

clothing$Store_Size <- ifelse(clothing$ssize < 100, "Small", ifelse(clothing$ssize <= 200, "Medium", "Large"))
clothing$Store_Size <- factor(clothing$Store_Size, levels = c("Small", "Medium", "Large"))

cat("NUMERICAL FEATURES\n")
print(names(clothing)[sapply(clothing, is.numeric)])

cat("CATEGORICAL FEATURES\n")
print(names(clothing)[sapply(clothing, is.factor)])

cat("CATEGORICAL FEATURE FREQUENCIES\n")
print(table(clothing$Margin_Level))
print(table(clothing$Store_Size))

write.csv(clothing, file.path(output_folder, "01_Clothing_With_Categorical_Features.csv"), row.names = FALSE)

cat("2. MISSING VALUE CREATION AND HANDLING\n")

missing_data <- clothing
missing_data$sales[c(5, 15, 25, 35, 45)] <- NA
missing_data$margin[c(10, 20, 30, 40, 50)] <- NA
missing_data$Margin_Level <- as.character(missing_data$Margin_Level)
missing_data$Margin_Level[c(60, 70, 80, 90, 100)] <- NA
missing_data$Margin_Level <- factor(missing_data$Margin_Level, levels = c("Low", "Medium", "High"))

cat("MISSING VALUE COUNTS\n")
print(colSums(is.na(missing_data)))

cat("ROWS WITH MISSING SALES\n")
print(which(is.na(missing_data$sales)))

cat("ROWS WITH MISSING MARGIN\n")
print(which(is.na(missing_data$margin)))

cat("ROWS WITH MISSING MARGIN LEVEL\n")
print(which(is.na(missing_data$Margin_Level)))

write.csv(missing_data, file.path(output_folder, "02_Clothing_With_Missing_Values.csv"), row.names = FALSE, na = "")

missing_discarded <- na.omit(missing_data)

cat("DIMENSION AFTER DISCARDING MISSING INSTANCES\n")
print(dim(missing_discarded))

write.csv(missing_discarded, file.path(output_folder, "03_Clothing_Missing_Instances_Discarded.csv"), row.names = FALSE)

find_mode <- function(x) {
  x <- x[!is.na(x)]
  frequency <- table(x)
  result <- names(frequency)[which.max(frequency)]
  return(result)
}

missing_replaced <- missing_data
average_sales <- mean(missing_replaced$sales, na.rm = TRUE)
average_margin <- mean(missing_replaced$margin, na.rm = TRUE)
frequent_margin_level <- find_mode(as.character(missing_replaced$Margin_Level))

missing_replaced$sales[is.na(missing_replaced$sales)] <- average_sales
missing_replaced$margin[is.na(missing_replaced$margin)] <- average_margin
missing_replaced$Margin_Level <- as.character(missing_replaced$Margin_Level)
missing_replaced$Margin_Level[is.na(missing_replaced$Margin_Level)] <- frequent_margin_level
missing_replaced$Margin_Level <- factor(missing_replaced$Margin_Level, levels = c("Low", "Medium", "High"))

cat("REPLACEMENT VALUES\n")
print(average_sales)
print(average_margin)
print(frequent_margin_level)

cat("MISSING COUNTS AFTER REPLACEMENT\n")
print(colSums(is.na(missing_replaced)))

write.csv(missing_replaced, file.path(output_folder, "04_Clothing_Missing_Values_Replaced.csv"), row.names = FALSE)

cat("3. NUMERICAL AND CATEGORICAL NOISE HANDLING\n")

noise_data <- missing_replaced
noise_data$sales[c(2, 12, 22)] <- c(100000, 150000, 200000)
noise_data$Store_Size <- as.character(noise_data$Store_Size)
noise_data$Store_Size[c(8, 18, 28)] <- "Wrong_Size"

sales_mean <- mean(noise_data$sales)
sales_sd <- sd(noise_data$sales)
lower_noise_limit <- sales_mean - 3 * sales_sd
upper_noise_limit <- sales_mean + 3 * sales_sd

numeric_noise_rows <- which(noise_data$sales < lower_noise_limit | noise_data$sales > upper_noise_limit)
categorical_noise_rows <- which(noise_data$Store_Size != "Small" & noise_data$Store_Size != "Medium" & noise_data$Store_Size != "Large")

cat("NUMERICAL NOISE ROWS\n")
print(numeric_noise_rows)

cat("CATEGORICAL NOISE ROWS\n")
print(categorical_noise_rows)

write.csv(noise_data, file.path(output_folder, "05_Clothing_With_Noise.csv"), row.names = FALSE)

valid_sales <- noise_data$sales[noise_data$sales >= lower_noise_limit & noise_data$sales <= upper_noise_limit]
noise_data$sales[numeric_noise_rows] <- mean(valid_sales)

valid_store_size <- noise_data$Store_Size[noise_data$Store_Size == "Small" | noise_data$Store_Size == "Medium" | noise_data$Store_Size == "Large"]
frequent_store_size <- find_mode(valid_store_size)
noise_data$Store_Size[categorical_noise_rows] <- frequent_store_size
noise_data$Store_Size <- factor(noise_data$Store_Size, levels = c("Small", "Medium", "Large"))

cat("NOISE CHECK AFTER HANDLING\n")
print(noise_data[c(2, 8, 12, 18, 22, 28), c("Store_ID", "sales", "Store_Size")])

write.csv(noise_data, file.path(output_folder, "06_Clothing_Noise_Handled.csv"), row.names = FALSE)

cat("4. INVALID DATA CHECKING AND HANDLING\n")

invalid_data <- noise_data
invalid_data$margin[c(4, 14, 24)] <- c(-10, -20, 150)
invalid_data$ssize[c(6, 16, 26)] <- c(0, -50, -100)
invalid_data$Margin_Level <- as.character(invalid_data$Margin_Level)
invalid_data$Margin_Level[c(9, 19, 29)] <- "Invalid"

invalid_margin_rows <- which(invalid_data$margin < 0 | invalid_data$margin > 100)
invalid_size_rows <- which(invalid_data$ssize <= 0)
invalid_category_rows <- which(invalid_data$Margin_Level != "Low" & invalid_data$Margin_Level != "Medium" & invalid_data$Margin_Level != "High")

cat("INVALID MARGIN ROWS\n")
print(invalid_margin_rows)

cat("INVALID STORE SIZE ROWS\n")
print(invalid_size_rows)

cat("INVALID CATEGORY ROWS\n")
print(invalid_category_rows)

write.csv(invalid_data, file.path(output_folder, "07_Clothing_With_Invalid_Data.csv"), row.names = FALSE)

valid_margin <- invalid_data$margin[invalid_data$margin >= 0 & invalid_data$margin <= 100]
valid_size <- invalid_data$ssize[invalid_data$ssize > 0]
valid_margin_level <- invalid_data$Margin_Level[invalid_data$Margin_Level == "Low" | invalid_data$Margin_Level == "Medium" | invalid_data$Margin_Level == "High"]

invalid_data$margin[invalid_margin_rows] <- mean(valid_margin)
invalid_data$ssize[invalid_size_rows] <- mean(valid_size)
invalid_data$Margin_Level[invalid_category_rows] <- find_mode(valid_margin_level)
invalid_data$Margin_Level <- factor(invalid_data$Margin_Level, levels = c("Low", "Medium", "High"))

cat("INVALID DATA COUNTS AFTER HANDLING\n")
print(sum(invalid_data$margin < 0 | invalid_data$margin > 100))
print(sum(invalid_data$ssize <= 0))
print(sum(!(as.character(invalid_data$Margin_Level) %in% c("Low", "Medium", "High"))))

write.csv(invalid_data, file.path(output_folder, "08_Clothing_Invalid_Data_Handled.csv"), row.names = FALSE)

cat("5. DATA NORMALIZATION AND TRANSFORMATION\n")

normalize <- function(x) {
  minimum_value <- min(x)
  maximum_value <- max(x)
  if (maximum_value == minimum_value) {
    return(rep(0, length(x)))
  }
  result <- (x - minimum_value) / (maximum_value - minimum_value)
  return(result)
}

normalized_data <- invalid_data
numeric_columns <- names(normalized_data)[sapply(normalized_data, is.numeric)]
numeric_columns <- numeric_columns[numeric_columns != "Store_ID"]

for (column_name in numeric_columns) {
  normalized_data[[column_name]] <- normalize(normalized_data[[column_name]])
}

cat("NORMALIZED DATA SUMMARY\n")
print(summary(normalized_data[numeric_columns]))

write.csv(normalized_data, file.path(output_folder, "09_Clothing_Normalized_Data.csv"), row.names = FALSE)

transformed_data <- invalid_data
transformed_data$Log_Total_Sales <- log(transformed_data$tsales + 1)
transformed_data$Log_Sales <- log(transformed_data$sales + 1)
transformed_data$Square_Root_Store_Size <- sqrt(transformed_data$ssize)

cat("TRANSFORMED DATA\n")
print(head(transformed_data[c("Store_ID", "tsales", "Log_Total_Sales", "sales", "Log_Sales", "ssize", "Square_Root_Store_Size")]))

write.csv(transformed_data, file.path(output_folder, "10_Clothing_Transformed_Data.csv"), row.names = FALSE)

cat("6. OUTLIER CHECKING AND HANDLING\n")

outlier_data <- invalid_data
outlier_columns <- c("tsales", "sales", "margin", "nown", "nfull", "npart", "naux", "hoursw", "hourspw", "inv1", "inv2", "ssize", "start")
outlier_result <- data.frame(Feature = character(0), Outlier_Count = integer(0), Outlier_Rows = character(0), stringsAsFactors = FALSE)

for (column_name in outlier_columns) {
  column_mean <- mean(outlier_data[[column_name]])
  column_sd <- sd(outlier_data[[column_name]])
  lower_limit <- column_mean - 3 * column_sd
  upper_limit <- column_mean + 3 * column_sd
  outlier_rows <- which(outlier_data[[column_name]] < lower_limit | outlier_data[[column_name]] > upper_limit)
  row_text <- ifelse(length(outlier_rows) == 0, "None", paste(outlier_rows, collapse = ", "))
  new_row <- data.frame(Feature = column_name, Outlier_Count = length(outlier_rows), Outlier_Rows = row_text, stringsAsFactors = FALSE)
  outlier_result <- rbind(outlier_result, new_row)
  if (length(outlier_rows) > 0) {
    normal_values <- outlier_data[[column_name]][outlier_data[[column_name]] >= lower_limit & outlier_data[[column_name]] <= upper_limit]
    outlier_data[[column_name]][outlier_rows] <- mean(normal_values)
  }
}

cat("OUTLIER RESULT\n")
print(outlier_result)

write.csv(outlier_result, file.path(output_folder, "11_Clothing_Outlier_Result.csv"), row.names = FALSE)
write.csv(outlier_data, file.path(output_folder, "12_Clothing_Updated_Clean_Dataset.csv"), row.names = FALSE)

cat("7. DESCRIPTIVE STATISTICS AND PLOTS\n")

statistics_columns <- c("tsales", "sales", "margin", "nown", "nfull", "npart", "naux", "hoursw", "hourspw", "inv1", "inv2", "ssize", "start")
statistics_table <- data.frame(
  Feature = statistics_columns,
  Mean = sapply(outlier_data[statistics_columns], mean),
  Median = sapply(outlier_data[statistics_columns], median),
  Standard_Deviation = sapply(outlier_data[statistics_columns], sd),
  Minimum = sapply(outlier_data[statistics_columns], min),
  Maximum = sapply(outlier_data[statistics_columns], max),
  stringsAsFactors = FALSE
)

rownames(statistics_table) <- NULL

cat("DATASET SUMMARY\n")
print(summary(outlier_data))

cat("DESCRIPTIVE STATISTICS TABLE\n")
print(statistics_table)

write.csv(statistics_table, file.path(output_folder, "13_Clothing_Descriptive_Statistics.csv"), row.names = FALSE)

png(file.path(output_folder, "Plot_1_Sales_Histogram.png"), width = 900, height = 650)
hist(outlier_data$sales, main = "Histogram of Sales", xlab = "Sales", ylab = "Frequency", breaks = 20)
dev.off()

png(file.path(output_folder, "Plot_2_Sales_Boxplot.png"), width = 900, height = 650)
boxplot(outlier_data$sales, main = "Boxplot of Sales", ylab = "Sales")
dev.off()

png(file.path(output_folder, "Plot_3_Sales_and_Margin.png"), width = 900, height = 650)
plot(outlier_data$margin, outlier_data$sales, main = "Sales and Margin", xlab = "Margin", ylab = "Sales", pch = 19)
dev.off()

png(file.path(output_folder, "Plot_4_Store_Size_Categories.png"), width = 900, height = 650)
barplot(table(outlier_data$Store_Size), main = "Store Size Categories", xlab = "Store Size", ylab = "Frequency")
dev.off()

cat("8. TRAINING AND TESTING DATA SPLIT\n")

set.seed(123)
random_rows <- sample(1:nrow(outlier_data), 3, replace = FALSE)

cat("THREE RANDOM ROWS\n")
print(outlier_data[random_rows, ])

testing_rows <- seq(5, nrow(outlier_data), by = 5)
training_rows <- setdiff(1:nrow(outlier_data), testing_rows)
training_data <- outlier_data[training_rows, ]
testing_data <- outlier_data[testing_rows, ]

cat("TRAINING DATA DIMENSION\n")
print(dim(training_data))

cat("TESTING DATA DIMENSION\n")
print(dim(testing_data))

write.csv(training_data, file.path(output_folder, "14_Clothing_Training_80_Percent.csv"), row.names = FALSE)
write.csv(testing_data, file.path(output_folder, "15_Clothing_Testing_20_Percent.csv"), row.names = FALSE)

cat("9. FEATURE SELECTION AND REGRESSION MODEL\n")

numeric_training_data <- training_data[sapply(training_data, is.numeric)]
numeric_training_data$Store_ID <- NULL
correlation_matrix <- cor(numeric_training_data)
sales_correlation <- correlation_matrix[, "sales"]
selected_features <- names(sales_correlation[abs(sales_correlation) >= 0.20 & names(sales_correlation) != "sales"])

if (length(selected_features) == 0) {
  other_correlations <- sales_correlation[names(sales_correlation) != "sales"]
  selected_features <- names(sort(abs(other_correlations), decreasing = TRUE))[1:3]
}

selected_feature_table <- data.frame(
  Feature = selected_features,
  Correlation_With_Sales = sales_correlation[selected_features],
  stringsAsFactors = FALSE
)

cat("SELECTED FEATURES\n")
print(selected_feature_table)

write.csv(correlation_matrix, file.path(output_folder, "16_Clothing_Correlation_Matrix.csv"), row.names = TRUE)
write.csv(selected_feature_table, file.path(output_folder, "17_Clothing_Selected_Features.csv"), row.names = FALSE)

model_formula <- as.formula(paste("sales ~", paste(selected_features, collapse = " + ")))
regression_model <- lm(model_formula, data = training_data)
predicted_sales <- predict(regression_model, newdata = testing_data)

regression_result <- data.frame(
  Store_ID = testing_data$Store_ID,
  Actual_Sales = testing_data$sales,
  Predicted_Sales = predicted_sales
)

rmse <- sqrt(mean((regression_result$Actual_Sales - regression_result$Predicted_Sales)^2))
mae <- mean(abs(regression_result$Actual_Sales - regression_result$Predicted_Sales))
r_squared <- 1 - sum((regression_result$Actual_Sales - regression_result$Predicted_Sales)^2) / sum((regression_result$Actual_Sales - mean(regression_result$Actual_Sales))^2)

model_metrics <- data.frame(
  Metric = c("RMSE", "MAE", "Test_R_Squared"),
  Value = c(rmse, mae, r_squared),
  stringsAsFactors = FALSE
)

cat("REGRESSION MODEL SUMMARY\n")
print(summary(regression_model))

cat("MODEL METRICS\n")
print(model_metrics)

cat("FIRST SIX PREDICTIONS\n")
print(head(regression_result))

write.csv(regression_result, file.path(output_folder, "18_Clothing_Regression_Predictions.csv"), row.names = FALSE)
write.csv(model_metrics, file.path(output_folder, "19_Clothing_Model_Metrics.csv"), row.names = FALSE)
capture.output(summary(regression_model), file = file.path(output_folder, "20_Clothing_Regression_Model_Summary.txt"))

criteria_table <- data.frame(
  Number = 1:9,
  Requirement = c(
    "Numerical and categorical features with more than 10 features",
    "Missing values handled by discarding and replacement",
    "Numerical and categorical noise detected and handled",
    "Invalid data detected and handled",
    "Normalization and transformation",
    "Outlier detection and handling",
    "Descriptive statistics and plots",
    "Training 80 percent and testing 20 percent split",
    "Feature selection with a regression model"
  ),
  Status = rep("Completed", 9),
  stringsAsFactors = FALSE
)

write.csv(criteria_table, file.path(output_folder, "00_Criteria_Compliance_Checklist.csv"), row.names = FALSE)

cat("PROJECT COMPLETED SUCCESSFULLY\n")
cat("OUTPUT FOLDER\n")
print(normalizePath(output_folder))
