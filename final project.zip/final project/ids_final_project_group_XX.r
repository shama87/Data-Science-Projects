input_file <- if (file.exists("train.En.csv")) "train.En.csv" 
data <- read.csv(input_file, stringsAsFactors = FALSE, fileEncoding = "UTF-8", check.names = FALSE)
if (!("source_id" %in% names(data))) data$source_id <- seq_len(nrow(data)) - 1
if (!("tweet" %in% names(data)) || !("sarcastic" %in% names(data))) stop("Required columns tweet and sarcastic were not found.")
data <- data[, c("source_id", "tweet", "sarcastic")]
data <- data[!is.na(data$tweet) & trimws(data$tweet) != "", ]
data <- data[!duplicated(data$tweet), ]
data$sarcastic <- as.integer(data$sarcastic)

clean_text <- function(x) {
  x <- tolower(x)
  x <- gsub("&amp;", " and ", x, fixed = TRUE)
  x <- gsub("&lt;", " ", x, fixed = TRUE)
  x <- gsub("&gt;", " ", x, fixed = TRUE)
  x <- gsub("https?://[^[:space:]]+", " ", x, perl = TRUE)
  x <- gsub("@[A-Za-z0-9_]+", " ", x, perl = TRUE)
  x <- gsub("#", " ", x, fixed = TRUE)
  x <- gsub("\\b(sarcasm|sarcastic|irony|ironic)\\b", " ", x, perl = TRUE)
  x <- gsub("[^a-z' ]", " ", x, perl = TRUE)
  x <- gsub("[[:space:]]+", " ", x, perl = TRUE)
  trimws(x)
}

stop_words <- strsplit("a an the and or but if while is are was were be been being to of in on at for from with as by this that these those it its i me my we our you your he his she her they their them do does did doing have has had having can could should would will just very really so too than then there here when where why how what which who whom because about into over under again further once all any both each few more most other some such only own same no not nor never", " ", fixed = TRUE)[[1]]
stop_words <- setdiff(stop_words, c("no", "not", "nor", "never"))

tokenize_text <- function(x) {
  words <- strsplit(x, " ", fixed = TRUE)[[1]]
  words <- words[nchar(words) > 1]
  words <- words[!(words %in% stop_words)]
  words
}

data$clean_text <- vapply(data$tweet, clean_text, character(1))
tokens <- lapply(data$clean_text, tokenize_text)
keep <- lengths(tokens) > 0
data <- data[keep, ]
tokens <- tokens[keep]
rownames(data) <- NULL

split_class <- function(class_value) {
  idx <- which(data$sarcastic == class_value)
  key <- (data$source_id[idx] * 37 + 17) %% 997
  ordered <- idx[order(key, data$source_id[idx])]
  n_test <- round(length(idx) * 0.20)
  list(test = ordered[seq_len(n_test)], train = ordered[-seq_len(n_test)])
}

split0 <- split_class(0)
split1 <- split_class(1)
train_idx <- sort(c(split0$train, split1$train))
test_idx <- sort(c(split0$test, split1$test))
train_y <- data$sarcastic[train_idx]
test_y <- data$sarcastic[test_idx]

train_terms <- unlist(tokens[train_idx], use.names = FALSE)
term_table <- table(train_terms)
term_frame <- data.frame(term = names(term_table), frequency = as.integer(term_table), stringsAsFactors = FALSE)
term_frame <- term_frame[order(-term_frame$frequency, term_frame$term), ]
max_terms <- min(100, nrow(term_frame))
vocabulary <- term_frame$term[seq_len(max_terms)]

build_bow <- function(indices) {
  out <- matrix(0, nrow = length(indices), ncol = length(vocabulary))
  colnames(out) <- paste0("x", seq_along(vocabulary))
  for (r in seq_along(indices)) {
    counts <- table(tokens[[indices[r]]])
    common <- intersect(names(counts), vocabulary)
    if (length(common) > 0) out[r, match(common, vocabulary)] <- as.numeric(counts[common])
  }
  out
}

bow_train <- build_bow(train_idx)
bow_test <- build_bow(test_idx)
document_frequency <- colSums(bow_train > 0)
idf <- log((nrow(bow_train) + 1) / (document_frequency + 1)) + 1
train_length <- pmax(rowSums(bow_train), 1)
test_length <- pmax(rowSums(bow_test), 1)
tfidf_train <- sweep(sweep(bow_train, 1, train_length, "/"), 2, idf, "*")
tfidf_test <- sweep(sweep(bow_test, 1, test_length, "/"), 2, idf, "*")

naive_bayes_predict <- function(train_x, train_y, test_x, alpha = 1) {
  classes <- c(0, 1)
  score <- matrix(0, nrow = nrow(test_x), ncol = 2)
  for (k in seq_along(classes)) {
    cls <- classes[k]
    class_x <- train_x[train_y == cls, , drop = FALSE]
    prior <- (nrow(class_x) + 1) / (nrow(train_x) + 2)
    feature_sum <- colSums(class_x) + alpha
    probability <- feature_sum / sum(feature_sum)
    score[, k] <- log(prior) + as.vector(test_x %*% log(probability))
  }
  classes[max.col(score, ties.method = "first")]
}

logistic_predict <- function(train_x, train_y, test_x) {
  train_df <- data.frame(y = train_y, train_x, check.names = FALSE)
  test_df <- data.frame(test_x, check.names = FALSE)
  model <- suppressWarnings(glm(y ~ ., data = train_df, family = binomial(), control = glm.control(maxit = 200)))
  probability <- suppressWarnings(predict(model, newdata = test_df, type = "response"))
  probability[is.na(probability)] <- mean(train_y)
  as.integer(probability >= 0.5)
}

evaluate_predictions <- function(actual, predicted) {
  tp <- sum(actual == 1 & predicted == 1)
  tn <- sum(actual == 0 & predicted == 0)
  fp <- sum(actual == 0 & predicted == 1)
  fn <- sum(actual == 1 & predicted == 0)
  accuracy <- (tp + tn) / length(actual)
  precision <- ifelse(tp + fp == 0, 0, tp / (tp + fp))
  recall <- ifelse(tp + fn == 0, 0, tp / (tp + fn))
  f1 <- ifelse(precision + recall == 0, 0, 2 * precision * recall / (precision + recall))
  cm <- matrix(c(tn, fp, fn, tp), nrow = 2, byrow = TRUE, dimnames = list(Actual = c("Non-sarcastic", "Sarcastic"), Predicted = c("Non-sarcastic", "Sarcastic")))
  list(Accuracy = accuracy, Precision = precision, Recall = recall, F1 = f1, Confusion = cm)
}

run_model <- function(representation, classifier, train_x, test_x) {
  predicted <- if (classifier == "Naive Bayes") naive_bayes_predict(train_x, train_y, test_x) else logistic_predict(train_x, train_y, test_x)
  evaluation <- evaluate_predictions(test_y, predicted)
  row <- data.frame(Representation = representation, Classifier = classifier, Accuracy = evaluation$Accuracy, Precision = evaluation$Precision, Recall = evaluation$Recall, F1 = evaluation$F1, stringsAsFactors = FALSE)
  list(row = row, confusion = evaluation$Confusion)
}

r1 <- run_model("BoW", "Naive Bayes", bow_train, bow_test)
r2 <- run_model("BoW", "Logistic Regression", bow_train, bow_test)
r3 <- run_model("TF-IDF", "Naive Bayes", tfidf_train, tfidf_test)
r4 <- run_model("TF-IDF", "Logistic Regression", tfidf_train, tfidf_test)
results <- rbind(r1$row, r2$row, r3$row, r4$row)
results <- results[order(-results$F1, -results$Accuracy), ]
rownames(results) <- NULL
write.csv(results, "model_results_group_XX.csv", row.names = FALSE)

cat("Dataset rows after cleaning:", nrow(data), "\n")
cat("Non-sarcastic:", sum(data$sarcastic == 0), "\n")
cat("Sarcastic:", sum(data$sarcastic == 1), "\n")
cat("Training rows:", length(train_idx), "\n")
cat("Test rows:", length(test_idx), "\n\n")
print(results)
cat("\nBoW + Naive Bayes Confusion Matrix\n")
print(r1$confusion)
cat("\nBoW + Logistic Regression Confusion Matrix\n")
print(r2$confusion)
cat("\nTF-IDF + Naive Bayes Confusion Matrix\n")
print(r3$confusion)
cat("\nTF-IDF + Logistic Regression Confusion Matrix\n")
print(r4$confusion)

png("class_distribution_group_XX.png", width = 900, height = 600)
barplot(c(sum(data$sarcastic == 0), sum(data$sarcastic == 1)), names.arg = c("Non-sarcastic", "Sarcastic"), main = "Class Distribution", ylab = "Number of Tweets")
dev.off()

png("model_f1_comparison_group_XX.png", width = 1100, height = 700)
barplot(results$F1, names.arg = paste(results$Representation, results$Classifier, sep = " + "), las = 2, ylim = c(0, 1), main = "BoW vs TF-IDF Model Comparison", ylab = "F1-score")
dev.off()
